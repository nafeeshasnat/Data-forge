# Internal Documentation

This folder contains technical, implementation-focused documentation for DataForge AI. It is meant for maintainers and contributors who need a deeper understanding of the code, algorithms, and architecture.

## Contents

- `app-functionality.md` - Feature-level behavior and UI capabilities.
- `architecture.md` - Application structure, boundaries, and component roles.
- `data-model.md` - Types, schemas, and data conventions.
- `algorithms.md` - Synthetic data generation logic and supporting calculations.
- `process-flow.md` - End-to-end flows for generation, download, and upload analysis.
- `math.md` - Equations and statistical models used in the generator.
- `tech-stack.md` - Technologies, libraries, and configuration details.
- `rationale-and-uniqueness.md` - Design rationale, uniqueness, and real-world usefulness.
