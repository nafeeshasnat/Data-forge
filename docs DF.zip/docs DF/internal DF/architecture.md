# Architecture

## High-level structure

- **Next.js App Router**: Routes live under `src/app/` with `page.tsx` and `layout.tsx` as entry points.
- **Client-rendered UI**: The main UI components are client components to enable stateful parameter controls, chart rendering, and local file handling.
- **Server actions**: Data generation and upload processing are implemented as server actions in `src/app/actions.ts`.
- **Shared library**: Core data generation logic and type definitions live in `src/lib/`.
- **AI flows**: Genkit flows are defined in `src/ai/` for analysis and parameter suggestions.

## Component boundaries

- `src/components/app/` contains feature-level UI: sidebar, dashboard, charts, AI insights, and logo.
- `src/components/ui/` contains ShadCN UI primitives for consistent styling and layout.
- `src/hooks/` provides small utilities like toasts and responsive checks.

## Rendering and data flow

- The generator page is a client component that calls a server action to generate data.
- The server action returns a `GenerationResult` object that is stored in component state.
- Charts receive typed data (`DataSummary` or `StudentWithCgpa[]`) and render visual summaries.
- The upload analyzer keeps all file operations on the client, then calls the server action to normalize and summarize the uploaded data.

## Configuration and hosting

- `next.config.ts` and `tsconfig.json` configure Next.js and TypeScript.
- `tailwind.config.ts` and `postcss.config.mjs` manage styling.
- `apphosting.yaml` provides Firebase App Hosting configuration (single-instance runtime by default).
