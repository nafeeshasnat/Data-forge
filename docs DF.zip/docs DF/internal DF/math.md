# Mathematical Foundations

This file summarizes the equations and distributions used in the generator and analytics.

## Random distributions

Uniform distribution (used for base GPA ranges and noise):

```
U(a, b) = a + rand() * (b - a)
```

Triangular distribution (used for mid performance base GPA):

```
Let u = rand()
Let f = (mode - low) / (high - low)
If u < f:
  x = low + sqrt(u * (high - low) * (mode - low))
Else:
  x = high - sqrt((1 - u) * (high - low) * (high - mode))
```

## Credit impact

```
deviation = (credits - stdCredit) / (maxCredit - minCredit)
impact = clamp(-maxCreditImpact, maxCreditImpact, -deviation * maxCreditImpact)
```

Where `clamp(a, b, x)` limits `x` to the range `[a, b]`.

## Semester GPA

```
baseGpa =
  high: U(3.6, 4.0)
  mid:  Triangular(2.8, 3.6, 3.3)
  fail: U(1.8, 2.4)

semesterGpa = clamp(0.0, 4.0, baseGpa * (1 + impact))
```

Subject-level noise:

```
subjectGpa = clamp(0.0, 4.0, semesterGpa + U(-0.3, 0.3))
```

Letter grades are assigned by comparing `subjectGpa` to the grade scale thresholds.

## Semester average GPA

For each semester, grade points are averaged across subjects:

```
semesterAvgGpa = sum(gradePoints) / subjectCount
```

## CGPA

CGPA is a credit-weighted average of semester GPAs:

```
CGPA = sum(semesterAvgGpa_i * creditHours_i) / sum(creditHours_i)
```

## Performance group (summary)

Performance groups for distribution charts are computed from CGPA:

```
if cgpa >= 3.5 -> high
if cgpa < 2.0  -> fail
else           -> mid
```
