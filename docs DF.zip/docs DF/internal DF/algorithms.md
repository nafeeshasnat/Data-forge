# Algorithms

## Synthetic data generation

The generator is implemented in `src/lib/data-generator.ts` and creates a list of `Student` records.

High-level steps for each student:
1. Select a department from `DEPARTMENTS`.
2. Sample a performance group (`high`, `mid`, `fail`) based on `highPerformanceChance` and `failChance`.
3. Build a subject pool from `SUBJECTS[department]` and shuffle it.
4. Iterate through the subject pool, assigning subjects into semesters based on credit load.
5. Compute a semester GPA from the performance group and workload impact.
6. Add random noise per subject and map GPA to a letter grade.
7. Build a student record with demographics and the semester map.

## Subject pools

`generateSubjectPool` constructs up to 50 subject entries for a department and removes duplicates with a set. The result is then shuffled to vary subject ordering across students.

## Semester construction

- Credit load is sampled as a random integer in `[minCredit, maxCredit]`.
- `subjectCount = ceil(credits / creditsPerSubject)`, bounded by remaining subjects.
- `actualCredits = subjectCount * creditsPerSubject` is recorded as `creditHours` for the semester.
- Attendance is a random integer in `[65, 100]`.

## GPA generation

- Base GPA is derived by performance group:
  - High: uniform in `[3.6, 4.0]`
  - Mid: triangular distribution with low 2.8, high 3.6, mode 3.3
  - Fail: uniform in `[1.8, 2.4]`
- Workload impact scales the semester GPA up or down based on deviation from `stdCredit`.
- GPA is clamped to `[0.0, 4.0]`.
- For each subject, additional noise in `[-0.3, 0.3]` is applied before converting to a letter grade.

## CGPA computation

`calculateStudentCgpa` in `src/app/actions.ts`:
- For each semester, compute the average grade points across subjects.
- Weight the semester GPA by `creditHours`.
- CGPA is the weighted average of all semesters.

## Summary metrics

`calculateSummary` in `src/app/actions.ts` computes:
- Total students.
- Average HSC GPA and CGPA.
- Department distribution.
- Performance distribution, where performance groups are derived from CGPA:
  - High if `cgpa >= 3.5`
  - Fail if `cgpa < 2.0`
  - Mid otherwise
