# Rationale, Uniqueness, and Real-World Use

## Structure rationale

- **Separation of concerns**: Generation logic and types live in `src/lib/`, while UI components are organized under `src/components/`.
- **Server actions for data generation**: Keeping generation on the server (`src/app/actions.ts`) centralizes logic and makes it reusable for both generated and uploaded datasets.
- **Reusable visualization layer**: The same dashboard and charts are shared between the generator and upload analyzer flows.
- **Typed data contract**: `GenerationParams` and `GenerationResult` provide a stable contract between UI and server actions.

## Uniqueness of the app

- Combines **synthetic data generation** with **immediate analytics** in one interface.
- Exposes the **parameter knobs** (performance distribution, workload impact) to help model different academic scenarios.
- Uses a **domain-aligned subject pool** per department to make the generated records realistic.
- Provides both **generation** and **analysis** modes, supporting workflows like comparison and validation.

## Real-world usefulness

- **Educational research**: Create datasets for analysis without sensitive student data.
- **Analytics testing**: Validate dashboards, ETL pipelines, and ML features on realistic synthetic data.
- **Product demos**: Showcase analytics features without a dependency on production data.
- **Curriculum planning**: Explore how course loads and performance distributions influence metrics.

## Known constraints and assumptions

- Department options are limited to CSE, EEE, and BBA as defined in `src/lib/subjects.ts`.
- Genkit AI flows are scaffolded but not wired into the UI.
- The generator uses randomized distributions, so results vary across runs.
- Upload analysis assumes input data conforms to the `Student` schema.
