# Process Flow

## Generation flow (root page)

1. `MainPage` initializes default `GenerationParams` and triggers a generate call on mount.
2. `generateDataAction` runs on the server and returns a `GenerationResult`.
3. The client stores the result and renders the dashboard.
4. The user can adjust parameters and re-run generation.
5. Toast notifications report success or failure.

## Download flow

1. User clicks "Download JSON".
2. The current `result.data` is serialized to JSON.
3. A Blob is created and a temporary anchor triggers file download.
4. A toast confirms the download start.

## Upload analysis flow

1. User selects a JSON file on the upload page.
2. The client validates `application/json` and reads content with `FileReader`.
3. JSON is parsed into `Student[]` and sent to `processUploadedData`.
4. The server action computes CGPA, summary metrics, and insights.
5. The dashboard renders the analysis view.

## Insights flow

- `generateDataAction` returns a static insights string for generated datasets.
- `processUploadedData` returns a different static insights string for uploaded data.
- Genkit flows exist under `src/ai/`, but are not currently invoked by the UI.
