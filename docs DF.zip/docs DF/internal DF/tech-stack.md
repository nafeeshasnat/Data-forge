# Tech Stack

## Runtime and framework

- **Next.js 15 (App Router)**: routing, server actions, and build pipeline.
- **React 19**: component UI and client state.
- **TypeScript**: strong typing across UI and data logic.

## UI and styling

- **Tailwind CSS**: utility-first styling.
- **ShadCN UI**: consistent UI primitives under `src/components/ui/`.
- **Lucide React**: icon set used across UI.

## Data visualization

- **Recharts**: pie, bar, and scatter plots for dashboard charts.

## AI tooling

- **Genkit**: flow definitions for data insights and parameter suggestions.
- **@genkit-ai/google-genai**: Google AI plugin configuration in `src/ai/genkit.ts`.

## Tooling and quality

- **ESLint**: linting via `next lint`.
- **TypeScript compiler**: `npm run typecheck` for static type checks.

## Hosting

- **Firebase App Hosting**: configured through `apphosting.yaml`.
