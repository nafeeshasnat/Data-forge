# App Functionality

## Core pages

### Generator (root page)
- Entry point is `src/app/page.tsx`, which renders `MainPage` from `src/components/app/main-page.tsx`.
- The generator page is a client-rendered dashboard with a parameter sidebar and a central analytics area.

### Upload analyzer
- The upload analyzer is in `src/app/upload/page.tsx`.
- It accepts a JSON file, parses it as `Student[]`, and runs the same summary calculations used for generated data.
- The resulting dashboard mirrors the generator view, enabling side-by-side analysis by reusing the same chart components.

## Parameter controls

The sidebar in `src/components/app/parameter-sidebar.tsx` provides:
- Slider + numeric input for `numStudents`.
- Slider + numeric input for `maxCreditImpact`.
- Slider + numeric input for `highPerformanceChance` and `failChance`.
- Generate and download buttons with loading feedback.
- A navigation link to the upload analyzer.

Default parameter values are defined in `src/components/app/main-page.tsx`.

## Dashboard and insights

The dashboard in `src/components/app/dashboard.tsx` includes:
- Stat cards for total students, average CGPA, and average HSC GPA.
- An AI insights card that displays an insights string.
- Tabs for demographics, academic performance, and subjects.

Charts are implemented with Recharts under `src/components/app/charts/`:
- Department distribution (pie)
- Performance group distribution (pie)
- Semester count distribution (bar)
- CGPA distribution (bar)
- HSC GPA vs CGPA scatter plot
- Credit hour distribution (bar)

## Download

The generator page provides a JSON download button that serializes `result.data` and triggers a file download named `synthetic_student_dataset.json`.

## Upload analysis

Upload flow details:
- Accepts only `application/json` files.
- Parses the file client-side and passes it to `processUploadedData` in `src/app/actions.ts`.
- Displays the file name on success and shows toast notifications on success or failure.

## AI-related functionality

The UI currently displays a static insights string returned by `generateDataAction`.
Genkit flows exist under `src/ai/` but are not currently wired to the UI.
