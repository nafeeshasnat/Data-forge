# Data Model

## Core types

Key interfaces defined in `src/lib/types.ts`:

- `GenerationParams`: inputs to the synthetic data generator.
- `Student`: a single student record with demographics and semester grades.
- `StudentWithCgpa`: a `Student` plus computed `cgpa`.
- `Semester`: a map of subject names to grades, plus `creditHours` and `attendancePercentage`.
- `DataSummary`: aggregated statistics for the dashboard.
- `GenerationResult`: the returned object from server actions (data + summary + insights).

## Sample student record

```json
{
  "student_id": 700100001,
  "ssc_gpa": 4.5,
  "hsc_gpa": 4.2,
  "gender": "female",
  "birth_year": 2001,
  "department": "CSE",
  "semesters": {
    "1": {
      "creditHours": 15,
      "attendancePercentage": 92,
      "Introduction to Programming": "A",
      "Discrete Mathematics": "B+"
    }
  }
}
```

## Grade scale

The grade scale used for GPA conversion is:

- A+ = 4.00
- A  = 3.75
- A- = 3.50
- B+ = 3.25
- B  = 3.00
- B- = 2.75
- C+ = 2.50
- C  = 2.25
- D  = 2.00
- F  = 0.00

## Summary fields

`DataSummary` includes:
- `totalStudents`
- `avgHscGpa`
- `avgCgpa`
- `departmentDistribution` (count by department)
- `performanceDistribution` (count by performance group)
