# Uniqueness and Real-World Usefulness

## Differentiators

- End-to-end workflow: dataset upload, training, monitoring, prediction, and reporting in one UI.
- Live training visibility: SSE log streaming shows model progress and system events.
- Multi-model benchmarking: Decision Tree, Random Forest, SVR, LightGBM, and MLP are compared side by side.
- Dual targets: final CGPA and next-sem CGPA are trained separately for longitudinal insight.
- Risk classification: explicit risk labels derived from quantiles plus a trained classifier.
- Export-ready reports: a Python exporter generates thesis-style plots and tables.

## Practical applications

- Academic advising: early identification of at-risk students for targeted interventions.
- Program evaluation: analyze cohorts and feature importances to discover drivers of success.
- Scenario planning: optional course-load adjustment to explore workload changes.
- Compliance and audit: prediction JSON outputs and artifact logs provide traceable records.

## Strengths for real-world deployment

- Multi-tenant design scoped by organization.
- Storage of artifacts on disk with static serving simplifies UI access.
- Config clamping and validation reduce unsafe hyperparameter choices.
- Modular separation between UI, API orchestration, and ML logic.

## Current limitations (from code behavior)

- Prediction depends on the presence of a recent successful model run.
- The heuristic course-load adjustment is not trained, only post-processed.
- Model performance depends on the quality and consistency of semester data.
