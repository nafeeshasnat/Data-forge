# Operations and Security

## Authentication model

- Access tokens are JWTs signed with `JWT_SECRET`.
- Refresh tokens are random hex strings stored as SHA-256 hashes.
- Refresh tokens are persisted per user and rotated on each refresh.
- Refresh token is stored in an httpOnly cookie scoped to `/api/auth`.
- Access tokens are stored in localStorage on the client.

Relevant files:
- `server/src/routes/auth.js`
- `server/src/auth.js`
- `src/lib/api.ts`

## API protection and org scoping

- Most endpoints require `authenticateToken` middleware.
- The middleware resolves the user and attaches `req.orgId`.
- All database queries filter by `orgId` to enforce tenancy isolation.

Relevant files:
- `server/src/auth.js`
- `server/src/routes/models.js`
- `server/src/routes/predict.js`

## Log streaming

- Training logs are written to `train.log` and streamed via SSE.
- The frontend reconnects on drop and uses offsets to resume.
- Log format includes `[INFO]`, `[WARN]`, `[ERROR]`, and `[PROGRESS]` markers.

Relevant files:
- `server/src/routes/models.js`
- `server/src/utils/log-stream.js`
- `src/components/LogStream.tsx`

## Resource cleanup

- Old uploads are pruned per org to keep only the most recent N files.
- Mirrored training logs are pruned by count.
- Cleanup is scheduled on server boot and runs on an interval.

Relevant files:
- `server/src/utils/cleanup.js`
- `server/src/index.js`

## Training termination

- The API exposes a terminate endpoint for active runs.
- Node stores active process IDs and sends SIGTERM then SIGKILL if needed.
- A termination notice is appended to `train.log`.

Relevant files:
- `server/src/routes/models.js`
- `server/src/utils/python-runner.js`

## Static artifact access

- Files under `server/storage` are served at `/static/*`.
- Paths are normalized with `toStaticPath` to prevent external references.

Relevant files:
- `server/src/lib/storage.js`
- `server/src/index.js`
