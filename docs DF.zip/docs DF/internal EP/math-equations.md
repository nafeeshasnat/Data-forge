# Mathematical Equations

This file captures the primary formulas used in `server/ml/train.py` and `server/ml/predict.py`. Notation is written in ASCII for clarity.

## Semester GPA

Given a semester with course grade points g_i:

```
semester_gpa = (1 / N) * sum_i(g_i)
```

Where N is the number of valid graded courses in the semester.

## Cumulative GPA (CGPA)

For semesters 1..k with semester GPA s_j and credit hours h_j:

```
cgpa_k = sum_j(s_j * h_j) / sum_j(h_j)
```

If credit hours are missing, a default can be substituted when configured.

## GPA trend across semesters

Let cgpa_1 be CGPA after the first semester and cgpa_s after s semesters:

```
gpa_trend = (cgpa_s - cgpa_1) / (s - 1)
```

## Temporal features

With a GPA time series x_t for t = 0..T-1:

- Slope (least-squares on index):
```
gpa_slope = cov(t, x_t) / var(t)
```

- Acceleration (mean second difference):
```
gpa_accel = mean( (x_{t} - x_{t-1}) - (x_{t-1} - x_{t-2}) )
```

- Volatility (standard deviation):
```
gpa_volatility = std(x_t)
```

Attendance trend uses the same slope computation on attendance values.

## Pass ratio and failed count

```
pass_ratio = passed_courses / attempted_courses
failed_count = count_of_failed_courses
```

A course is considered passed if its numeric grade >= PASS_GPA_MIN (default 2.0).

## Ensemble prediction

For model predictions p_m across M models:

```
ensemble_mean = (1 / M) * sum_m(p_m)
```

## Risk thresholds and labels

Risk thresholds are derived from the training fold of next-sem CGPA:

```
q_high = quantile(y_train, 0.30)
q_med  = quantile(y_train, 0.70)
```

Given predicted next-sem CGPA y_hat:

```
if y_hat <= q_high: risk = High
else if y_hat <= q_med: risk = Medium
else: risk = Low
```

## Course-load adjustment (optional)

When credit hours are supplied at prediction time:

```
course_load = clamp(credit_hours / 3, 1.0, 7.0)
scale = 1 + coeff * ((course_load - base_load) / base_load)
scale = clamp(scale, 0.92, 1.08)

adjusted_prediction = prediction * scale
```

`coeff` is 0.10 in the current implementation. This adjustment is a heuristic and not part of training.
