# Technology Stack

## Frontend (Vite + React)
- React 18 + TypeScript (`src/main.tsx`, `src/App.tsx`).
- Vite build system and dev server (`vite.config.ts`, `package.json`).
- TailwindCSS with utility + animation helpers (`tailwind.config.ts`, `src/index.css`).
- Radix UI primitives and local UI wrappers (`src/components/ui/*`).
- Recharts for dashboards and model plots (`src/pages/DashboardSummary.tsx`).
- React Router for page routing (`src/App.tsx`).
- React Hook Form for forms and input handling (`src/components/ui/form.tsx`).
- TanStack React Query for data fetching in some views (`package.json`).
- Lucide React icon set (`lucide-react`).

## Backend (Node + Express)
- Express HTTP server and routing (`server/src/index.js`, `server/src/routes/*`).
- Prisma ORM with PostgreSQL (`server/prisma/schema.prisma`).
- JWT auth with refresh tokens (`server/src/routes/auth.js`).
- Multer for JSON upload handling (`server/src/lib/uploads.js`).
- Zod for Python result validation (`server/src/schemas/*`).
- SSE endpoints for log and summary streaming (`server/src/routes/models.js`).

## ML + Data Science (Python)
- Data processing: NumPy, Pandas (`server/ml/train.py`, `server/ml/predict.py`).
- Classical ML: scikit-learn (DecisionTree, RandomForest, SVR, metrics).
- Gradient boosting: LightGBM (`lightgbm` package).
- Neural net: PyTorch MLP with early stopping.
- Imbalanced classification: SMOTE (`imblearn.over_sampling.SMOTE`).
- Plotting: Matplotlib + optional Seaborn.
- Model persistence: joblib + torch save/load.

## Storage + Artifact Management
- File-based storage under `server/storage` for uploads, model artifacts, and predictions.
- Static file serving mapped to `/static` (`server/src/index.js`, `server/src/lib/storage.js`).
- Automatic cleanup of old uploads and logs (`server/src/utils/cleanup.js`).

## Tooling
- ESLint + TypeScript for frontend linting.
- Nodemon for backend dev reload (`server/nodemon.json`).
- Docker compose for Postgres (`docker-compose.yml`).
