# Data Models and Storage

## Database schema (PostgreSQL via Prisma)

Defined in `server/prisma/schema.prisma`.

- Organization
  - `id` (cuid), `name`, `createdAt`
  - Relations: `users`, `modelRuns`, `preds`

- User
  - `id`, `orgId`, `email`, `passwordHash`
  - `refreshTokenHash`, `refreshTokenExpires` for refresh token rotation
  - Indexed by `(orgId, createdAt)`

- ModelRun
  - `id`, `orgId`, `status`
  - `config` JSON (training parameters)
  - `metrics` JSON, `plots` JSON, `artifactsDir` string
  - `createdAt`, `finishedAt`

- Prediction
  - `id`, `orgId`, `studentId`
  - `inputPath`, `outFile`
  - `results` JSON (raw predictions)
  - `summary` JSON (UI-friendly summary)
  - `createdAt`

## On-disk storage layout

`server/storage/` is used for all file artifacts and is served under `/static`:

```
server/storage/
├── uploads/<orgId>/
│   └── train_<timestamp>.json
├── models/<orgId>/<runId>/
│   ├── config.json
│   ├── train.log
│   ├── metadata.json
│   ├── report.json
│   ├── plots/
│   ├── artifacts/
│   └── *.joblib / *.pt
└── predictions/<orgId>/
    ├── student_<timestamp>.json
    └── prediction_<timestamp>.json
```

Key storage helpers are in:
- `server/src/lib/storage.js` (static path normalization)
- `server/src/lib/uploads.js` (org-scoped upload destinations)

## Data contracts between Node and Python

- Training output: `__RESULT__{...}` with `status`, `metrics`, `plots`, `bestModel`, `artifactsDir`, etc.
- Prediction output: `__RESULT__{...}` with `predictions`, `risk`, `current`, and `plots`.

Validation occurs in:
- `server/src/schemas/trainingResult.js`
- `server/src/schemas/predictionResult.js`
