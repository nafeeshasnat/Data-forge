# Architecture and Structure Rationale

## High-level architecture

The system is split into three major planes:

1) Frontend UI (React)
- Renders dashboards, config forms, charts, and log viewers.
- Talks only to the backend API via `src/lib/api.ts`.

2) Backend API (Node/Express)
- Provides auth, training, prediction, and export endpoints.
- Orchestrates Python ML scripts via child processes.
- Manages persistence in Postgres and on-disk storage.

3) ML pipeline (Python)
- Owns data cleaning, feature engineering, model training, and prediction.
- Emits progress and results via a strict stdout protocol consumed by Node.

## Folder layout

- `src/` - React UI, charts, and feature pages.
- `server/src/` - API server, routes, utils, auth.
- `server/ml/` - Python training, prediction, and export scripts.
- `server/prisma/` - Prisma schema for Postgres.
- `server/storage/` - Run artifacts, plots, logs, inputs, and outputs.

## Rationale for separation

- UI is purely client-side, which allows fast iteration and a clean API contract.
- The backend focuses on orchestration, storage, and security boundaries.
- Python ML stays isolated, which allows independent dependency management and reproducible results.
- Storage is file-based for artifacts (plots, model binaries, logs) and relational for metadata.

## Boundary contracts

- Python scripts must print a single `__RESULT__{...}` JSON line when finished.
- Training logs are written to `train.log` and streamed via SSE to the UI.
- Prediction outputs are saved to JSON for auditability and replay.

## Key code anchors

- Backend entry: `server/src/index.js`
- ML orchestration: `server/src/utils/python-runner.js`
- Training script: `server/ml/train.py`
- Prediction script: `server/ml/predict.py`
- UI routing: `src/App.tsx`
