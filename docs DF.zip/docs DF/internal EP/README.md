# Internal Documentation

This folder contains technical documentation for the Grade Grade Wise application. Each file focuses on one facet of the system and references the source files that implement it.

## Index

- `docks/internal/app-functionality.md` - User-facing features and dashboard capabilities.
- `docks/internal/technology-stack.md` - Frontend, backend, ML, and tooling dependencies.
- `docks/internal/architecture-and-structure.md` - Folder layout and design rationale.
- `docks/internal/process-flows.md` - End-to-end flows for training, prediction, logging, and export.
- `docks/internal/ml-pipeline.md` - Data cleaning, feature engineering, model training, and evaluation.
- `docks/internal/data-models-storage.md` - Database schema and on-disk storage layout.
- `docks/internal/math-equations.md` - Equations used for GPA and feature computations.
- `docks/internal/operations-and-security.md` - Auth model, logging, cleanup, and operational behavior.
- `docks/internal/uniqueness-real-world.md` - Differentiators and real-world usefulness.

## Source anchors

- Backend server: `server/src/index.js`, `server/src/routes/*.js`
- ML scripts: `server/ml/train.py`, `server/ml/predict.py`, `server/ml/export_thesis_results.py`
- Frontend: `src/pages/*`, `src/components/*`, `src/lib/api.ts`
- Data model: `server/prisma/schema.prisma`
