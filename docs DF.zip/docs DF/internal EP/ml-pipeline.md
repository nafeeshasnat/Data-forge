# ML Pipeline Details

This section describes how `server/ml/train.py` and `server/ml/predict.py` transform input data into predictions.

## Input schema (training)

- Training data is a JSON array of student records.
- Each record may contain:
  - `student_id` (string or number)
  - `ssc_gpa`, `hsc_gpa` (floats)
  - `gender` (string)
  - `birth_year` (int)
  - `department` (string, optional)
  - `semesters` (dict keyed by semester number, or a list of semester objects)
- Each semester may contain:
  - `attendancePercentage` (0..100)
  - `creditHours` (1..30)
  - Course grades either under `courses: []` or as fields on the semester object

See `server/ml/samples/train_small.json` for a concrete example.

## Data cleaning and normalization

Implemented in `server/ml/train.py` (e.g. `sanitize_student`, `sanitize_semester`).

- Coerces numeric fields; drops invalid or non-finite values.
- Clamps attendance to [0, 100], credit hours to [1, 30].
- Grades are normalized to numeric GPA values using `GRADE_POINTS`.
- Duplicated semesters and courses are merged with preference to existing values.
- Keeps counters for invalid/missing data to avoid hard failures.

## Feature engineering

The model uses a fixed feature order:

- `ssc_gpa`, `hsc_gpa`
- `gender_bin` (1 for female, 0 otherwise)
- `birth_year`
- `avg_credit_hours`
- `avg_attendance`
- `gpa_trend` (slope between first and most recent CGPA)
- `gpa_slope`, `gpa_accel`, `gpa_volatility` (temporal stats)
- `att_slope`, `att_delta`
- `pass_ratio`, `failed_count`

The temporal features are computed across semester sequences to capture trends and consistency.

## Training targets

Two separate targets are trained:

1) Final CGPA prediction
- Uses all but the last semester to predict the final cumulative CGPA.

2) Next-semester CGPA prediction
- Uses rolling windows: for each student, semesters 1..s predict semester s+1.
- This expands the dataset while preventing student leakage via group splits.

## Model suite

The training script can enable any combination of:

- DecisionTreeRegressor
- RandomForestRegressor
- SVR / LinearSVR (optional grid search tuning)
- LightGBM LGBMRegressor
- PyTorch MLP (scaled inputs, early stopping)

The best model is selected by lowest test RMSE (tie-broken by train RMSE).

## Evaluation and reporting

Metrics are computed per model on train and test splits:

- RMSE
- MAE
- R2

Additional artifacts:

- Prediction samples (actual vs predicted)
- Feature importance (native for RF/LGBM; permutation for MLP)
- Learning curves for LGBM and MLP
- Histograms for final CGPA and next-sem CGPA

## Risk classification

- Risk labels are based on next-sem CGPA thresholds.
- Thresholds are set by training-fold quantiles (30% and 70%).
- A RandomForestClassifier is trained on the next-sem features.
- SMOTE is applied to balance classes before training the risk classifier.
- If the data has only one label, a DummyClassifier is used.

## Prediction and ensemble

During prediction (`server/ml/predict.py`):

- Each enabled model outputs a final CGPA and next-sem CGPA.
- Ensemble prediction is the mean of available model outputs.
- Risk is derived by comparing ensemble next-sem CGPA to learned thresholds.
- Optional course-load adjustment scales predictions based on credit-hour inputs.

## Artifacts

Training writes into the run directory:

- `metadata.json` (best model, enabled models, thresholds, feature order)
- `report.json` (metrics, plots, feature importance, confusion matrix)
- Model binaries: `*.joblib`, `MLP*.pt`
- Plots: PNGs for residuals, feature importance, confusion matrix, etc.
- `train.log`

These are served via `/static/...` for frontend display.
