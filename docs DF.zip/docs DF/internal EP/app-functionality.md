# App Functionality

This app is a full-stack grade prediction system that lets an organization train ML models on historical student data, monitor training in real time, and generate predictions for new students.

## Core user capabilities

1) Authentication and org setup
- Sign up creates an organization and user account.
- Sign in issues a JWT and refresh token.
- Auth-protected routes enforce org scoping.
- Implemented in `server/src/routes/auth.js` and `server/src/auth.js`.

2) Model training
- Upload a JSON training dataset and configuration parameters.
- Server validates and clamps config values before passing to Python.
- Training starts asynchronously; users can watch live progress via SSE.
- Training artifacts, logs, plots, and metrics are stored under `server/storage/models/<orgId>/<runId>`.
- Implemented in `server/src/routes/models.js`, `server/src/utils/python-runner.js`, `server/ml/train.py`.

3) Training monitoring and summary
- Log streaming: SSE endpoint streams `train.log` updates.
- Summary endpoint returns latest successful run metrics, plots, and report JSON.
- Frontend displays metrics cards, histograms, confusion matrices, and learning curves.
- Implemented in `server/src/routes/models.js`, `src/components/LogStream.tsx`, `src/pages/DashboardSummary.tsx`.

4) Prediction workflow
- Upload a single student JSON file to run predictions with the latest trained model.
- Returns per-model predictions plus an ensemble mean for final CGPA and next-sem CGPA.
- Provides optional course-load adjustment output when credit hours are supplied.
- Predictions are persisted and shown in history.
- Implemented in `server/src/routes/predict.js`, `server/ml/predict.py`, `src/pages/DashboardPredict.tsx`.

5) History and retraining
- Prediction history lists recent prediction records (max 50).
- Retrain flow allows new datasets/configs while pruning older runs.
- Implemented in `src/pages/DashboardHistory.tsx`, `src/pages/DashboardRetrain.tsx`.

6) Export
- Generates a zipped report for thesis/analysis artifacts from the latest run.
- Implemented in `server/src/routes/export.js`, `server/ml/export_thesis_results.py`.

## Frontend pages and components

- `src/pages/TrainModel.tsx` and `src/pages/TrainModels.tsx`: training UI and config entry.
- `src/pages/DashboardSummary.tsx`: model summary, metrics, plots, and configs.
- `src/pages/DashboardPredict.tsx`: prediction input and results visualization.
- `src/components/GradeScaleEditor.tsx`: grade point mapping editor.
- `src/components/LogStream.tsx`: SSE log viewer.

## API surface (high level)

- Auth: `POST /api/auth/signup`, `POST /api/auth/signin`, `POST /api/auth/refresh`, `POST /api/auth/signout`, `GET /api/auth/me`
- Training: `POST /api/models/train`, `GET /api/models/train/:runId/logs`, `POST /api/models/train/:runId/terminate`
- Summary: `GET /api/models/summary`, `GET /api/models/summary/stream`, `GET /api/models/status`
- Prediction: `POST /api/predict`, `GET /api/predict`, `GET /api/predict/:id`, `DELETE /api/predict`
- Export: `POST /api/export`, `GET /api/export/download?file=...`
