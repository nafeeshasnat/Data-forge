# Process Flows

## Training flow

1) UI sends `POST /api/models/train` with JSON dataset and config.
2) Server validates config (`server/src/utils/validate-config.js`).
3) Server creates a `ModelRun` record (status PENDING -> RUNNING).
4) Upload is stored under `server/storage/uploads/<orgId>`.
5) Training output directory created at `server/storage/models/<orgId>/<runId>`.
6) `python-runner` spawns `server/ml/train.py` and tail-writes stdout to `train.log`.
7) Python emits `__PROGRESS__{...}` and `__RESULT__{...}` lines.
8) On success, backend updates `ModelRun` to SUCCEEDED with metrics + plots.
9) On failure, backend marks run FAILED and logs the error.

Relevant files:
- `server/src/routes/models.js`
- `server/src/utils/python-runner.js`
- `server/ml/train.py`

## Live log streaming (SSE)

1) UI opens EventSource to `/api/models/train/:runId/logs` with token.
2) Backend verifies JWT and org ownership.
3) Backend reads `train.log` incrementally and pushes chunks with `id` offsets.
4) Client appends log content, highlights progress lines, and auto-reconnects.

Relevant files:
- `server/src/routes/models.js`
- `server/src/utils/log-stream.js`
- `src/components/LogStream.tsx`

## Prediction flow

1) UI sends `POST /api/predict` with student JSON file.
2) Backend looks up latest SUCCEEDED model for the org.
3) `python-runner` spawns `server/ml/predict.py` with artifacts dir.
4) Script loads models and metadata, builds features, and emits predictions.
5) Backend persists prediction record and returns hydrated response.

Relevant files:
- `server/src/routes/predict.js`
- `server/src/utils/python-runner.js`
- `server/ml/predict.py`

## Export flow

1) UI calls `POST /api/export`.
2) Backend finds latest SUCCEEDED run and runs export script.
3) Export script packages plots and summary tables into a zip.
4) Client downloads from `/api/export/download?file=...`.

Relevant files:
- `server/src/routes/export.js`
- `server/ml/export_thesis_results.py`

## Auth flow

1) Sign up creates org + user and issues JWT + refresh cookie.
2) Sign in verifies password and rotates refresh token.
3) Refresh uses httpOnly cookie to mint a new access token.
4) Client stores access token in localStorage; refresh is automatic on 401.

Relevant files:
- `server/src/routes/auth.js`
- `src/lib/api.ts`
